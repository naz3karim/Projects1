

public class Candle {
	private int height;
	private int width;
	private float price;
	private boolean is_lit;
	//constructor  with 3 arguments
	public Candle(int height, int width, float price) {
		super();
		this.height = height;
		this.width = width;
		this.price = price;
		this.is_lit=false;
	}
//getter and setter of all attributes
	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public boolean isIs_lit() {
		return is_lit;
	}
//to string function
	@Override
	public String toString() {
		return height + ","+price + "," + is_lit+"\n";
	}

	public void setIs_lit(boolean is_lit) {
		this.is_lit = is_lit;
	}

	
}
