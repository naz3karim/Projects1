
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;


public class Project1 {
	
	//main methond
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 File file = new File("input.txt");//reading file
		 int lengthh=10000;
		  String[] lines = new String[lengthh];
		
		    FileReader reader = new FileReader(file);
		    BufferedReader buffReader = new BufferedReader(reader);
		    int size = 0;
		    String s;
		    while((s = buffReader.readLine()) != null){
		        lines[size] = s;
		        size++;
		    }
		    
		    
		    
		    //2 temporary array
		    Candle[] temporay_array1=new Candle[size];
		    Candle[] temporay_array2=new Candle[size];
		    
		    
		    //initializing temporary variables
		    int size_of_array=0;
		    int h,w;
		     float pricee=0;
		     String tt="";
		     
		     
		     //loop that calculating each things
		    for (int i=0;i<size;i++) {//iterate over the lines of files 
		    	
		    	StringTokenizer tokens = new StringTokenizer(lines[i],",");
			    
			    
			     int total_tokens=0;
			    pricee=0;
			    h=0;
			    w=0;
			     tt="";
			     
			     
			    while (tokens.hasMoreTokens())
			    {
			    	//System.out.println(total_tokens);
			    	
			        if (total_tokens==0) {
			        	h=Integer.parseInt(tokens.nextToken());
			        	
			        }
			        else if (total_tokens==1) {
			        	w=Integer.parseInt(tokens.nextToken());
			        }
			        else if (total_tokens==2) {
			        	pricee=Float.parseFloat(tokens.nextToken());
			        }
			        else {
			        	tt=tt+","+tokens.nextToken();
			        	total_tokens+=1;
			        	
			        }
			        
		        	total_tokens+=1;
			    }
			     if (total_tokens==3) {
			    	 temporay_array1[size_of_array]=new Candle(h,w,pricee);
			    	 temporay_array2[size_of_array]=new Candle(h,w,pricee);
			    	 size_of_array+=1;
			     }
			     else {
			    	// System.out.println(i+1  +" line Number contain more than 3 things,Details of that row is below:-");
			    	 System.out.println(String.valueOf(h)+","+String.valueOf(w)+","+String.valueOf(pricee)+tt);
			     }
			   
		    }
		    
		    
		    //doing selection sort
		    //sorting one candels array on basis of price
		  
		    
	        // One by one move boundary of unsorted subarray
	        for (int i = 0; i < size_of_array-1; i++)
	        {
	            // Find the minimum price in unsorted array
	            int min_idx = i;
	            for (int j = i+1; j < size_of_array; j++)
	                if (temporay_array1[j].getPrice()	 < temporay_array1[min_idx].getPrice())
	                    min_idx = j;
	 
	            // Swap the found minimum price candle with the first
	            // element
	            Candle temp1 = temporay_array1[min_idx];
	            temporay_array1[min_idx] = temporay_array1[i];
	            temporay_array1[i] = temp1;
	        }
	        //calling gui object
	        CandleGUI objectGui=new CandleGUI();
	        
	        //calling fundtion to dispaly candle information
	        objectGui.display(temporay_array1, temporay_array2, size_of_array);
		    
		    
		    
	}

}
