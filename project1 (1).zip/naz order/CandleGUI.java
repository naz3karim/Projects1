import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class CandleGUI {
	//main function to call
public void display(Candle temporay_array1[],Candle temporay_array2[],int size_of_array ) {
	//making Jframe to show in frame
	 JFrame frame = new JFrame("Candle Status");
     JPanel panel = new JPanel(new GridLayout(1,2));
  String textt="";
  //loop that concatening unsorted array candle
     for(int i=0;i<size_of_array;i++) {
 	 textt=textt+temporay_array2[i].toString();
  }
        panel.add(new JTextArea(textt));
        textt="";
        //combining each candle according to input file formattng
        for(int i=0;i<size_of_array;i++) {
     	   
	    	 textt=textt+temporay_array1[i].toString();
	     }
        //add text in panel area
	           panel.add(new JTextArea(String.valueOf(textt)));
	           
	      //CandleGUI.adding panel in frame to show
     frame.add(panel);
     frame.setSize(650, 300);
     frame.setVisible(true);
}
}
